tinyMCE.addI18n("it.vipersvideoquicktags",{
	youtube : "Inserisci un video da YouTube",
	googlevideo : "Inserisci un video da Google Video",
	dailymotion : "Inserisci un video da DailyMotion",
	vimeo : "Inserisci un video da Vimeo",
	veoh : "Inserisci un video da Veoh",
	viddler : "Inserisci un video da Viddler",
	metacafe : "Inserisci un video da Metacafe",
	bliptv : "Inserisci un video da Blip.tv",
	flickrvideo : "Inserisci un video da Flickr",
	spike : "Inserisci da IFILM / Spike.com",
	myspace : "Inserisci un video da MySpace",
	flv : "Inserisci un file video Flash (FLV)",
	quicktime : "Inserisci un file video Quicktime",
	videofile : "Inserisci un generico file video"
});