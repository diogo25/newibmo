=== Categories Images ===
Contributors: elzahlan
Tags: Category Image, Categories Images, admin, texonomy image, category icon, category logo
Requires at least: 2.8
Tested up to: 3.4
Stable tag: 1.2

The Categories Images Plugin allow you to add image with category or taxonomy.

== Description ==

The Categories Images Plugin allow you to add image with category or taxonomy.

Use `<?php if (function_exists('z_taxonomy_image_url')) echo z_taxonomy_image_url(); ?>` to get the url and put it in any img tag in (category or taxonomy) template.

= More documentation =

Go to [http://zahlan.net/blog/2012/06/categories-images/](http://zahlan.net/blog/2012/06/categories-images/)

== Installation ==

You can install Categories Images directly from the WordPress admin panel:

	1. Visit the Plugins > Add New and search for 'Categories Images'.
	2. Click to install.
	3. Once installed, activate and it is functional.
	
OR

Manual Installation:

	1. Download the plugin, then extract it.
	2. Upload `categories-images` extracted folder to the `/wp-content/plugins/` directory
	3. Activate the plugin through the 'Plugins' menu in WordPress
	
You're done! The Plugin ready to use, for more please check the plugin description.

= More documentation =

Go to [http://zahlan.net/blog/2012/06/categories-images/](http://zahlan.net/blog/2012/06/categories-images/)

== Frequently Asked Questions ==

Please check the documentation page:
[http://zahlan.net/blog/2012/06/categories-images/](http://zahlan.net/blog/2012/06/categories-images/)

== Screenshots ==

1. new image field in add/edit category or taxonomy.
2. click the image field and wordpress upload box will popup.

== Changelog ==

= 1.2 =
Adding some screenshots

= 1.1 =
Fix javascript bug with wordpress 3.4

= 1.0 =
The First Release
